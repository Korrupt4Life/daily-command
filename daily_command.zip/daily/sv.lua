RegisterCommand('gift', function(source, args, user) 
	local source = source
	local identifier = vRP.getUserId({source})
    exports.ghmattimysql:execute("SELECT * FROM cadouuuu WHERE id = @id", {id = identifier}, function(rows)
		local nextcollect = os.time() + 86400
		if rows[1] then
			if parseInt(((rows[1].time-os.time())/60/60)) < 1 then
				local sansa = math.random(1,8)
				if sansa == 1 then
					vRP.giveInventoryItem({identifier, "body_armor", 5, true})
					TriggerClientEvent("chat:addMessage", source, {color={255,0,0}, multiline=false, args={"Daily Gift", "Ai primit 5 Armuri"}})
				elseif sansa == 2 then
					vRP.giveInventoryItem({identifier, "injectieadr", 10, true})
					TriggerClientEvent("chat:addMessage", source, {color={255,0,0}, multiline=false, args={"Daily Gift", "Ai primit 10 Injectii de Adrenalina"}})
				elseif sansa == 3 then
					vRP.giveInventoryItem({identifier, "supressor", 1, true})
					TriggerClientEvent("chat:addMessage", source, {color={255,0,0}, multiline=false, args={"Daily Gift", "Ai primit un Supressor"}})
				elseif sansa == 4 then
					vRP.giveDovleci({identifier, 30})
					TriggerClientEvent("chat:addMessage", source, {color={255,0,0}, multiline=false, args={"Daily Gift", "Ai primit 30 de cadouri"}})
				else
					vRP.giveMoney({identifier, 75000})
					TriggerClientEvent("chat:addMessage", source, {color={255,0,0}, multiline=false, args={"Daily Gift", "Ai primit 75.000$"}})
				end
				exports.ghmattimysql:execute("UPDATE cadouuuu SET time = @time WHERE id = @id", {time = nextcollect, id = identifier})
			else
				TriggerClientEvent("chat:addMessage", source, {color={255,0,0}, multiline=false, args={"Daily Gift", "Mai ai de asteptat "..parseInt(((rows[1].time-os.time())/60/60)).." ore pentru a deschide Daily Gift-ul"}})
			end
		else
			vRP.giveMoney({identifier, 75000})
            TriggerClientEvent("chat:addMessage", source, {color={255,0,0}, multiline=false, args={"Daily Gift", "Ai primit 75.000$"}})
			exports.ghmattimysql:execute("INSERT IGNORE INTO cadouuuu (id, time) VALUES (@id, @time)", {id = identifier, time = nextcollect})
		end
	end)
end)