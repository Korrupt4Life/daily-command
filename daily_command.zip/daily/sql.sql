CREATE TABLE `cadouuuu` (
  `id` int(11) DEFAULT NULL,
  `time` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;